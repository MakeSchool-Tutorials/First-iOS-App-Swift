#import <Foundation/Foundation.h>
#import <Nimble/NMBExceptionCapture.h>
#import <Nimble/DSL.h>

FOUNDATION_EXPORT double NimbleVersionNumber;
FOUNDATION_EXPORT const unsigned char NimbleVersionString[];
