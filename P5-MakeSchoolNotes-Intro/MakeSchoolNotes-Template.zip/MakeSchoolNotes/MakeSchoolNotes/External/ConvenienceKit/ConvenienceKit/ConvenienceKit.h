//
//  ConvenienceKit.h
//  ConvenienceKit
//
//  Created by Benjamin Encz on 4/10/15.
//  Copyright (c) 2015 Benjamin Encz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ConvenienceKit.
FOUNDATION_EXPORT double ConvenienceKitVersionNumber;

//! Project version string for ConvenienceKit.
FOUNDATION_EXPORT const unsigned char ConvenienceKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ConvenienceKit/PublicHeader.h>


